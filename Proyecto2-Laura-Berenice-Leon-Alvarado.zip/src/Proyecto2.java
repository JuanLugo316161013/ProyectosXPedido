/**
 * Clase principal para el Proyecto 2;
 * @author Laura Berenice León Alvarado.
 * @version 2a edición.
 */
public class Proyecto2 {
    public static void main( String[] args ) {
    	VentanillaEscolar ventanilla = new VentanillaEscolar();
    	ventanilla.mostrarServicios();
    }
}